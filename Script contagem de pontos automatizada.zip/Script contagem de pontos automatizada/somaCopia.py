import requests
from requests.auth import HTTPBasicAuth
from datetime import datetime, timedelta, timezone
import pandas as pd
import os 

# --- Configurações de acesso ao Jira ---
JIRA_URL = "https://ddsinfo.atlassian.net"
JIRA_USER = "daniel@ddsinfo.com.br"
JIRA_TOKEN = ""

if not JIRA_TOKEN:
    print("ERRO: O token da API do Jira não foi encontrado.")
    print("Por favor, defina a variável de ambiente 'JIRA_API_TOKEN' ou cole o token diretamente no script.")
    exit()

CUSTOM_POINT_FIELD = "customfield_10069" # Campo de Pontos
CUSTOM_DATE_FIELD = "customfield_10231" # Campo de Data da Sprint
CUSTOM_POINT_FIELD = "customfield_10069" # Campo de Pontos
# ... (outras configs) ...


# Headers e autenticação
headers = {
    "Accept": "application/json",
    "Content-Type": "application/json"
}
auth = HTTPBasicAuth(JIRA_USER, JIRA_TOKEN)

# Lista dos status que contam pontos
status_alvo = [
    "3.3 Revisão de Código","4.0 A testar", "4.2 Mergear", "4.3 Pend. Versão",
    "4.4 A Testar (homologação)", "4.5 A testar (artefato)",
    "5.3 Pendência de Homolog", "6.0 Concluído",
    "6.1 Pend. Gerar Artefatos", "6.2 Pend. Envio Homolog."
]

# Definição dos tipos de item que são "Sustentação"
TIPOS_SUSTENTACAO = ["erro", "atendimento","Retorno Negativo (RN)"]

# Define a data da sprint 
inicio = datetime(2026, 2, 9, tzinfo=timezone.utc) #data inicial
fim = datetime(2026, 2, 22, hour=23, minute=59, second=59, tzinfo=timezone.utc) # data final
periodos = [(inicio, fim)]

# Função que processa um projeto (elfa ou star)
def obter_dados_projeto(projeto):
    dados = []
    next_token = ""

    while True:
        # Busca issues do projeto com changelog expandido
        jql = f'project = "{projeto}" AND TYPE != Bug ORDER BY created DESC'
        
      
        params = {
            "jql": jql,
            "fields": f"{CUSTOM_POINT_FIELD},{CUSTOM_DATE_FIELD},assignee,status,issuetype",
            "expand": "changelog",
            "maxResults": 50
        }

        if next_token:
            params["nextPageToken"] = next_token

        resp = requests.get(f"{JIRA_URL}/rest/api/3/search/jql", headers=headers, auth=auth, params=params)
        
        try:
            resp.raise_for_status()
        except requests.exceptions.HTTPError as e:
            print(f"Erro na requisição ao Jira: {e}")
            print(f"Resposta: {resp.text}")
            break 

        data_json = resp.json()

        for issue in data_json["issues"]:
            key = issue["key"]
            changelog = issue.get("changelog", {}).get("histories", [])
            data_transicao = None

            # Identifica a primeira transição para status alvo
            for hist in sorted(changelog, key=lambda x: x["created"]):
                for item in hist.get("items", []):
                    if item["field"] == "status" and item["toString"] in status_alvo:
                        data_transicao = datetime.fromisoformat(hist["created"].replace("Z", "+00:00"))
                        break
                if data_transicao:
                    break

            # Ignora se nunca entrou em status alvo
            if not data_transicao:
                continue

            periodo_sprint = None
            periodo_inicio = None

            # Define em qual sprint a transição ocorreu
            for (ini, fim) in periodos:
                if ini <= data_transicao <= fim:
                    periodo_sprint = ini.strftime("%Y-%m-%d")
                    periodo_inicio = ini
                    break

            # Ignora se não caiu em nenhum período
            if not periodo_sprint:
                continue

            # Obtém nome do responsável
            assignee = issue["fields"].get("assignee")
            dev = assignee["displayName"] if assignee else "Sem responsável"

            # Obtém pontos
            pontos_raw = issue["fields"].get(CUSTOM_POINT_FIELD)
            try:
                pontos = int(pontos_raw["value"]) if pontos_raw and "value" in pontos_raw else 0
            except (ValueError, TypeError):
                pontos = 0

            # --- INÍCIO DA NOVA LÓGICA DE CATEGORIZAÇÃO ---
            
            # Obtém o tipo de item (Bug, Task, Story, Erro, etc.)
            typeIssue = issue["fields"].get("issuetype") 
            tipo_item_nome = typeIssue["name"].lower() if typeIssue else "sem tipo"

            pontos_sustentacao = 0
            pontos_desenvolvimento = 0

            if tipo_item_nome in TIPOS_SUSTENTACAO:
                pontos_sustentacao = pontos
            else:
                pontos_desenvolvimento = pontos
                
            # --- FIM DA NOVA LÓGICA ---

            # Adiciona registro para a planilha 
            dados.append({
                "Período": periodo_sprint,
                "Responsável": dev,
                "Pontos_Sustentacao": pontos_sustentacao,
                "Pontos_Desenvolvimento": pontos_desenvolvimento
            })
            
            # Define data que deve ser salva no campo (início da sprint)
            data_iso = periodo_inicio.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+0000"

            campo_data_existente = issue["fields"].get(CUSTOM_DATE_FIELD)
            precisa_atualizar = False

            # Verifica se o campo precisa ser atualizado (vazio ou data diferente)
            if campo_data_existente is None:
                precisa_atualizar = True
            else:
                data_existente_str = campo_data_existente.split("T")[0]
                data_esperada_str = periodo_inicio.strftime("%Y-%m-%d")
                if data_existente_str != data_esperada_str:
                    precisa_atualizar = True

            # Atualiza o campo se necessário
            if precisa_atualizar:
                payload = {
                    "fields": {
                        CUSTOM_DATE_FIELD: data_iso
                    }
                }
                update_resp = requests.put(
                    f"{JIRA_URL}/rest/api/3/issue/{key}",
                    headers=headers,
                    auth=auth,
                    json=payload
                )
                if update_resp.status_code == 204:
                    print(f"✅ Issue {key} atualizada com data {data_iso}")
                else:
                    print(f"❌ Falha ao atualizar issue {key}: {update_resp.text}")

        
        # Checa paginação
        listaItens = data_json.get("issues", []) 
        if data_json.get("isLast") or not listaItens:
            break
        
        next_token = data_json.get("nextPageToken")
        
        if not next_token:
            break

    return dados

# Gera planilhas com soma de pontos por período e responsável
def gerar_planilha(dados, nome_arquivo):
    if not dados:
        print(f"⚠️ Nenhum dado retornado para {nome_arquivo}.")
        return
    
    df = pd.DataFrame(dados)
    
    # Agrupa e soma as novas colunas
    df_agrupado = df.groupby(["Período", "Responsável"], as_index=False).agg({
        "Pontos_Sustentacao": "sum",
        "Pontos_Desenvolvimento": "sum"
    })

    df_agrupado["Pontos_Total"] = df_agrupado["Pontos_Sustentacao"] + df_agrupado["Pontos_Desenvolvimento"]
    
    # Ordena do maior total para o menor
    df_agrupado = df_agrupado.sort_values(by="Pontos_Total", ascending=False)
    
    df_agrupado.to_excel(nome_arquivo, index=False)
    print(f"✅ Planilha '{nome_arquivo}' gerada.")


# --- Execução Principal ---
try:
    print("Processando projeto ELFA...")
    dados_elfa = obter_dados_projeto("ELFA")
    gerar_planilha(dados_elfa, "pontos_ELFA2.xlsx")
    
    print("\nProcessando projeto STAR...")
    dados_star = obter_dados_projeto("STAR")
    gerar_planilha(dados_star, "pontos_STAR2.xlsx")
    
    print("\nProcesso concluído.")

except Exception as e:
    print(f"\nOcorreu um erro inesperado: {e}")